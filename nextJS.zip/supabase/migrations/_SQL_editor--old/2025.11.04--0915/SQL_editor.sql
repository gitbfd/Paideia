-- Promote your user to admin (current approach = profiles.role)
-- Your schema’s default is student, so you must flip it:

-- 1) Find your user id (the auth.users id)
select id, email from auth.users order by created_at desc limit 10;

-- 2) Ensure there is a matching profiles row (create if missing)
insert into public.profiles (id, email, role)
values ('<AUTH_USER_UUID>', '<you@example.com>', 'admin')
on conflict (id) do update set role = 'admin', email = excluded.email;

-- 3) Verify
select id, email, role from public.profiles where id = '<AUTH_USER_UUID>';
